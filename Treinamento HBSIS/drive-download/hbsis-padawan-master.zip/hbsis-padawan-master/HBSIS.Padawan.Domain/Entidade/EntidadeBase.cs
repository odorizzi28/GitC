﻿using System;

namespace HBSIS.Padawan.Domain.Entidade
{
    public class EntidadeBase
    {
        public Guid Id { get; set; }
    }
}
